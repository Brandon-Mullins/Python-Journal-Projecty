# Simple To-Do List Program
# This program lets users add tasks, view them, mark them as completed, and delete them.

# Import os module for file handling
import os

# File where tasks will be saved
TASK_FILE = "tasks.txt"


# Function to load tasks from file
def load_tasks():
    if not os.path.exists(TASK_FILE):  # If file doesn't exist, return empty list
        return []
    with open(TASK_FILE, "r") as file:
        return [task.strip() for task in file.readlines()]


# Function to save tasks to file
def save_tasks(tasks):
    with open(TASK_FILE, "w") as file:
        for task in tasks:
            file.write(task + "\n")  # Save each task on a new line


# Function to display menu options
def show_menu():
    print("\nTo-Do List")
    print("1. Add Task")
    print("2. View Tasks")
    print("3. Mark Task as Completed")
    print("4. Delete Task")
    print("5. Exit")


# Function to add a task
def add_task():
    task = input("Enter task: ")
    tasks = load_tasks()
    tasks.append("[ ] " + task)  # Mark as incomplete
    save_tasks(tasks)
    print("Task added!")


# Function to display tasks
def view_tasks():
    tasks = load_tasks()
    if not tasks:
        print("No tasks yet!")
    else:
        for i, task in enumerate(tasks, start=1):
            print(f"{i}. {task}")


# Function to mark a task as completed
def complete_task():
    tasks = load_tasks()
    view_tasks()

    try:
        task_num = int(input("Enter task number to mark complete: ")) - 1
        if 0 <= task_num < len(tasks):
            tasks[task_num] = tasks[task_num].replace("[ ]", "[✔]")  # Mark complete
            save_tasks(tasks)
            print("Task marked as complete!")
        else:
            print("Invalid task number.")
    except ValueError:
        print("Enter a valid number!")


# Function to delete a task
def delete_task():
    tasks = load_tasks()
    view_tasks()

    try:
        task_num = int(input("Enter task number to delete: ")) - 1
        if 0 <= task_num < len(tasks):
            removed_task = tasks.pop(task_num)
            save_tasks(tasks)
            print(f"Deleted: {removed_task}")
        else:
            print("Invalid task number.")
    except ValueError:
        print("Enter a valid number!")


# Main function
def main():
    while True:
        show_menu()
        choice = input("Choose an option: ")

        if choice == "1":
            add_task()
        elif choice == "2":
            view_tasks()
        elif choice == "3":
            complete_task()
        elif choice == "4":
            delete_task()
        elif choice == "5":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")


# Run the program
if __name__ == "__main__":
    main()
